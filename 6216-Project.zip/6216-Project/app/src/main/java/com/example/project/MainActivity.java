package com.example.project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.graphics.drawable.AnimationDrawable;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity<as> extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }

    public void onClickNext(View view) {
        Intent intent = new Intent(MainActivity.this, opencategories.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(intent);
    }

    public void onClick(View v) {
        Intent intentback = new Intent(MainActivity.this, instructions.class);
        startActivity(intentback);
    }
}
